<template>
<div class="ordering">
    <p>添加学生22222222</p>
</div>
</template>



<script>
export default {
    name:'AddStudent',
}

</script>



<style scoped>

</style>